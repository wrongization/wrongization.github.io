#include "lib.h"

int main() {
	return 0;
}
