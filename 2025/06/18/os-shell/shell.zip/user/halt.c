#include <lib.h>

int main() {
	user_halt("halt mos!");
}
