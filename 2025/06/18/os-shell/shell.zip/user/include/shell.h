#ifndef SHELL_H
#define SHELL_H
//tokens
#define WHITESPACE " \n\t\r"
#define SYMBOLS "<|>&;()`"
#define TOKEN_WHITESPACE 0

#define TOKEN_WORD 257
#define TOKEN_APPEND 258// >>
#define	TOKEN_AND 259// &&
#define	TOKEN_OR 260// ||

#define PIPE_JUDGE_NORMAL 0
#define PIPE_JUDGE_PIPEEND 1
#define PIPE_JUDGE_MAINOUT 2

#define JUDGE_AND 11
#define JUDGE_OR  10

#define MAXARGS 80
#define MAXTEMPDUP 60

#define MAX_COMMAND_LENGTH 1024

#define MAX_LOCAL_KEYLEN 25
#define MAX_LOCAL_VALUELEN 25
#define MAX_LOCAL_VARCOUNT 25

#define HISTORY_FILE "/.HISTORY_FILE"
#define HISTORY_FILE_SIZE 20
struct LocalVar {
	char key[MAX_LOCAL_KEYLEN];
	char value[MAX_LOCAL_VALUELEN];
	int writable;
};
struct tempFd {
	int size;
	int temp[MAXTEMPDUP][2];
};


//shellio.c

int replace_sign(char* command);
void read_command(char* cmd_buf, int max_len) ;
void history_init();
int replace_backquote(char* command);


//paser.c
int _gettoken(char *s, char **p1, char **p2);
int gettoken(char *s, char **p1);
int parsecmd(char **argv, int *rightpipe,struct tempFd * tempfd,int *pipeend,int* inpipe,int * judge);
int resetdup(struct tempFd * tempfd);
int savedup(struct tempFd * tempfd,int from);
int is_builtin(char *cmd) ;

//exec

//内建
int execute_cd(int argc, char **argv);
int execute_pwd(int argc, char **argv);
int execute_exit(int argc, char **argv);
int execute_history(int argc, char **argv);
//local 
int set_local_var(char* key, char* value, int writable);
int remove_local_var(char* key);
//全局 declare
int execute_declare(int argc, char **argv);
void print_all_variables() ;
int set_variable(int is_env_var, char* key, char* value, int writable) ;
//全局 unset
int execute_unset(int argc, char **argv);
int get_var(char* key, char* value);

int runcmd(char *s,struct tempFd *tempfd,int* rightpipe,int argc,char **argv,int pipeend);

#endif
