#include <env.h>
#include <lib.h>
#include <mmu.h>

void exit(int exit_code) {
    //void exit(void)
#if !defined(LAB) || LAB >= 5
	close_all();
#endif

	syscall_env_exit(0, exit_code);
    //syscall_env_destroy(0);
	user_panic("unreachable code");
}

const volatile struct Env *env;
extern int main(int, char **);

void libmain(int argc, char **argv) {
	env = &envs[ENVX(syscall_getenvid())];

	int exit_code = main(argc, argv);
    //main(argc, argv);

	exit(exit_code);
    //exit();
}
