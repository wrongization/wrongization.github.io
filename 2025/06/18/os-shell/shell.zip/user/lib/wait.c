#include <env.h>
#include <lib.h>
int wait(u_int envid) {
//void wait(u_int envid) {
    //
	const volatile struct Env *e;

	e = &envs[ENVX(envid)];
	while (e->env_id == envid) {
        //new
		if (e->env_status == ENV_FREE) {
			return 1;
		} else if (e->env_status == ENV_END) {
			int exit_code = e->env_exit_code;
			syscall_env_destroy(envid);
			return exit_code;
		}
        //
		syscall_yield();
	}
    //new return ;
	return 1;
    //
}
