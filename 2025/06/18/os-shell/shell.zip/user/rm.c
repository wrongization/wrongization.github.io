#include <lib.h>

int flag[256];

int rm(char *path)
{
	struct Stat st;
	int r = stat(path, &st);
	if (r < 0)
	{
		if (flag['r'] && flag['f'])
		{
			return 0;
		}
		else
		{
			printf("rm: cannot remove '%s': No such file or directory\n", path);
			return 1;
		}
	}
	if (st.st_isdir && !flag['r'])
	{
		printf("rm: cannot remove '%s': Is a directory\n", path);
		return 1;
	}
	r = remove(path);
	return 0;
}

void usage() {
	printf("usage: rm [-rf] <file>\n");
	exit(1);
}

int main(int argc, char **argv) {
	ARGBEGIN {
	default:
		usage();
	case 'r':
	case 'f':
		flag[(u_char)ARGC()]++;
		break;
	}
	ARGEND
	if (argc != 1) {
		usage();
	}
	int ret = rm(argv[0]);
	return ret;
}
