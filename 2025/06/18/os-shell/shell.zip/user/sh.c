#include <args.h>
#include <lib.h>
#include <shell.h>
void init_shell_body(int year) {
    printf("\n:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::\n");
    printf("::                                                         ::\n");
    printf("::                     MOS Shell %d                      ::\n", year);
    printf("::                                                         ::\n");
    printf(":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::\n");
}

char buf[MAX_COMMAND_LENGTH];

void sh_usage(void) {
    printf("usage: sh [-ix] [script-file]\n");
    exit(1);
}

int main(int argc, char **argv) {
    int r;
    int interactive = iscons(0);
    int echocmds = 0;
    init_shell_body(2024);
    ARGBEGIN {
    case 'i':
        interactive = 1;
        break;
    case 'x':
        echocmds = 1;
        break;
    default:
        sh_usage();
    }
    ARGEND

    if (argc > 1) {
        sh_usage();
    }
    if (argc == 1) {
        close(0);
        if ((r = open(argv[0], O_RDONLY)) < 0) {
            user_panic("open %s: %d", argv[0], r);
        }
        user_assert(r == 0);
    }
    
    history_init();
    for (;;) {
        if (interactive) {
            printf("\n$ ");
        }
        read_command(buf, sizeof buf);
        replace_sign(buf);
        replace_backquote(buf);

        if (echocmds) {
            printf("# %s\n", buf);
        }
        char singlebuf[MAX_COMMAND_LENGTH];

        int cmds = count_mulline(buf);

        for(int i=0;i<=cmds;i++){
            devide_mulline(buf, singlebuf, i);
    
            struct tempFd tempfd;
            tempfd.size=0;

            gettoken(singlebuf, 0);

            char *argv[MAXARGS];
            int rightpipe = 0;
            int pipeend = 0;
            int inpipe = 0;
            int judge = 0;
            int argc = parsecmd(argv, &rightpipe,&tempfd,&pipeend,&inpipe,&judge);
            int returncode=0;


            //debugf("pipeend %d   argc : %d\n",pipeend,argc);
            if(inpipe){
                runcmd(singlebuf,&tempfd,&rightpipe,argc,argv,pipeend);
            }
            else{

            returncode=runcmd(singlebuf,&tempfd,&rightpipe,argc,argv,pipeend);
            
            }
            //debugf(">>judge:%d  argc:%d  returncode:%d\n",judge,argc,returncode);
            while(judge!=0){
                int should=0;
                if(judge==JUDGE_AND){
                    should = (returncode==0);
                }
                if(judge==JUDGE_OR){
                    should = (returncode!=0);
                }
                //debugf(">>>>>%d\n",should);
                rightpipe = 0;
                pipeend = 0;
                inpipe = 0;
                judge = 0;  

                argc = parsecmd(argv, &rightpipe,&tempfd,&pipeend,&inpipe,&judge);
                //debugf(">>%d %d %d\n",judge,argc,returncode);

                if(should){
                    if(inpipe){
                    runcmd(singlebuf,&tempfd,&rightpipe,argc,argv,pipeend);
                    }
                    else{
                    returncode=runcmd(singlebuf,&tempfd,&rightpipe,argc,argv,pipeend);
                    }
                }

            }
        }

        
        
    }
    close_all();
    return 0;
}