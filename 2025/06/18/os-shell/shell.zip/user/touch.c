#include <lib.h>

int touch(char *path)
{
	struct Stat st;
	int r = stat(path, &st);
	if (r >= 0)
	{
		return 0;
	}
	r = create(path, 0);
	if (r < 0)
	{
		printf("touch: cannot touch '%s': No such file or directory\n", path);
		return 1;
	}
	else
	{
		return 0;
	}
}

void usage() {
	printf("usage: touch <file>\n");
	exit(1);
}

int main(int argc, char **argv) {
	if (argc != 2) {
		usage();
	}
	int ret = touch(argv[1]);
	return ret;
}
