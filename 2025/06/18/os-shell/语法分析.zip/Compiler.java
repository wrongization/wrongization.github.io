import frontend.Lexer;
import frontend.Parser;
import frontend.nodes.Token;
import frontend.nodes.Unit;
import frontend.result.TokenResult;
import frontend.result.UnitResult;

import java.io.*;
import java.util.ArrayList;

public class Compiler {
    public static void main(String[] args) throws IOException {
        File inputFile = new File("testfile.txt");
        if (!inputFile.exists()) {
            inputFile.createNewFile();
        }
        File lexerOutput = new File("lexer.txt");
        if (!lexerOutput.exists()) {
            lexerOutput.createNewFile();
        }
        File errorOutput = new File("error.txt");
        if (!errorOutput.exists()) {
            errorOutput.createNewFile();
        }
        File parserOutput = new File("parser.txt");
        if (!parserOutput.exists()) {
            parserOutput.createNewFile();
        }
        ArrayList<String> errors = new ArrayList<>();
        ArrayList<Token> tokens = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(inputFile));
             BufferedWriter lexerWriter = new BufferedWriter(new FileWriter(lexerOutput));
             BufferedWriter errorWriter = new BufferedWriter(new FileWriter(errorOutput));
             BufferedWriter parserWriter = new BufferedWriter(new FileWriter(parserOutput))) {
            // 读取输入文件，进行词法分析
            String line;
            int lineNumber = 0;
            TokenResult tokenresult = new TokenResult();
            //处理reader里的注释，包括//和/* */
            boolean inBlockComment = false;
            while ((line = reader.readLine()) != null) {
                // 从1开始计数行号
                lineNumber++;

                // 预处理行，去除注释
                StringBuilder processedLine = new StringBuilder();
                int i = 0;
                while (i < line.length()) {
                    if(!inBlockComment){
                        if (i < line.length() - 1 && line.charAt(i) == '/' && line.charAt(i + 1) == '/') {
                            // 单行注释，跳过剩余部分
                            break;
                        } else if (i < line.length() - 1 && line.charAt(i) == '/' && line.charAt(i + 1) == '*') {
                            // 开始块注释
                            inBlockComment = true;
                            i += 2; // 跳过 /*
                        } else {
                            // 非注释部分，添加到结果中
                            processedLine.append(line.charAt(i));
                            i++;
                        }
                    }
                    else {
                        if (i < line.length() - 1 && line.charAt(i) == '*' && line.charAt(i + 1) == '/') {
                            // 结束块注释
                            inBlockComment = false;
                            i += 2; // 跳过 */
                        } else {
                            // 在块注释内，跳过字符
                            i++;
                        }
                    }
                }

                // 如果整行是空的，跳过
                if (processedLine.isEmpty()) { continue; }

                // 调用 Lexer 进行词法分析
                Lexer.analyzeLine(lineNumber,processedLine.toString(),tokenresult);

            }
            // 记录所有token
            tokens.addAll(tokenresult.tokens);
            // 处理错误信息和输出
            outputlexer(lexerWriter,errors,tokenresult);
            // 词法分析完成
            System.out.println("词法分析完成！");

            // 语法分析
            Unit root = new Unit(1, Unit.UnitType.CompUnit);
            UnitResult result = new UnitResult();
            Parser.analyze(tokens,result);
            outputparser(parserWriter,errors,result);
            // 语法分析完成
            System.out.println("语法分析完成！");
            // 对errors进行排序并且输出
            outputerror(errorWriter,errors);

        }
        catch (IOException e) {
            e.printStackTrace();
        }

    }
    // 输出token和错误信息方法
    public static void outputlexer(BufferedWriter lexerWriter,ArrayList<String> errors,TokenResult result) throws IOException  {
        if (!result.Success) {
            // 有错误时写入错误文件
            for (String errorMessage : result.errorMessages) {
                errors.add(errorMessage);
            }
        }
        // 写入词法分析结果
        for (Token token : result.tokens) {
            lexerWriter.write(token.toString());
            lexerWriter.newLine();
        }
    }

    // 输出语法分析和错误信息方法
    public static void outputparser(BufferedWriter parseWriter, ArrayList<String> errors, UnitResult result) throws IOException  {
        Unit root = result.root;
        if (!result.Success) {
            // 有错误时写入错误文件
            for (String errorMessage : result.errorMessages) {
                errors.add(errorMessage);
            }
        }
        // fixme))语法树左偏
        // 写入语法分析结果
        if (root != null) {
            root.output(parseWriter);
        }
    }
    // 对error.txt进行排序
    public static void outputerror(BufferedWriter errorWriter,ArrayList<String> errors) throws IOException {
        // 对errors按行号排序
        errors.sort((a, b) -> {
            String[] partsA = a.split(" ");
            String[] partsB = b.split(" ");
            int lineA = Integer.parseInt(partsA[0]);
            int lineB = Integer.parseInt(partsB[0]);
            return Integer.compare(lineA, lineB);
        });
        try {
            for (String error : errors) {
                errorWriter.write(error);
                errorWriter.newLine();
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

}