package frontend.BNF;

import frontend.nodes.Node;
import frontend.nodes.Token;
import frontend.nodes.Unit;
import frontend.result.UnitResult;

import java.util.ArrayList;
import java.util.List;

public class Gram {

    // 辅助函数
    private static Token at(ArrayList<Token> tokens, int pos) {
        return pos < tokens.size() ? tokens.get(pos) : null;
    }

    private static Token.TokenType TokenTypeat(ArrayList<Token> tokens, int pos) {
        return pos < tokens.size() ? tokens.get(pos).getType() : null;
    }

    private static boolean is(ArrayList<Token> tokens, int pos, Token.TokenType t) {
        Token tk = at(tokens, pos);
        return tk != null && tk.getType() == t;
    }

    private static int expectToken(UnitResult result,Unit parent,
       ArrayList<Token> tokens, int pos, Token.TokenType t) {
        if (!is(tokens, pos, t)) {
            // 语法错误，输出前一个token的行号和错误类型
            if (t == Token.TokenType.SEMICN) {
                result.addErrorMessage(parent.getLineNumber(),"i");
            } else if (t == Token.TokenType.RPARENT) {
                result.addErrorMessage(parent.getLineNumber(),"j");
            } else if (t == Token.TokenType.RBRACK) {
                result.addErrorMessage(parent.getLineNumber(),"k");
            } else {
                // 其他情况输出该行错误
                //result.addErrorMessage(at(tokens, pos-1).getLineNumber(),t.toString());
            }
            result.Success = false;
            return pos;
        }
        parent.addChild(tokens.get(pos));
        return pos + 1;
    }

    private static Unit makeUnit(int line, Unit.UnitType type) {
        return new Unit(line, type);
    }

    public static class nodepos {
        public final Node node;
        public final int pos;
        public nodepos(Node node, int pos) {
            this.node = node;
            this.pos = pos;
        }
    }
    // CompUnit -> {Decl} {FuncDef} MainFuncDef
    public class CompUnit {
        private static ArrayList<Token.TokenType> FirstToken = new ArrayList<>();

        public static List<Token.TokenType> getFirstToken() {
            return FirstToken;
        }
        static {
            getFirstToken().addAll(Decl.getFirstToken());
        }

        public static nodepos parse(ArrayList<Token> tokens, int pos, UnitResult result) {
            int line = (pos < tokens.size()) ? tokens.get(pos).getLineNumber() : 0;
            Unit node = makeUnit(line, Unit.UnitType.CompUnit);
            // Debug print first tokens of all non-terminals
            //        CompUnit,
            //        Decl,
            //        ConstDecl,
            //        BType,
            //        VarDecl,
            //        VarDef,
            //        InitVal,
            //        FuncDef,
            //        FuncType,
            //        MainFuncDef,
            //        FuncFParams,
            //        FuncFParam,
            //        Block,
            //        BlockItem,
            //        Stmt,
            //        ForStmt,
            //        Exp,
            //        Cond,
            //        LVal,
            //        PrimaryExp,
            //        Number,
            //        UnaryExp,
            //        UnaryOp,
            //        FuncRParams,
            //        MulExp,
            //        AddExp,
            //        RelExp,
            //        EqExp,
            //        LAndExp,
            //        LOrExp,
            //        ConstExp,
            /*
            {
                System.out.println("CompUnit: " + CompUnit.getFirstToken().toString());
                System.out.println("Decl: " + Decl.getFirstToken().toString());
                System.out.println("ConstDecl: " + ConstDecl.getFirstToken().toString());
                System.out.println("BType: " + BType.getFirstToken().toString());
                System.out.println("VarDecl: " + VarDecl.getFirstToken().toString());
                System.out.println("VarDef: " + VarDef.getFirstToken().toString());
                System.out.println("InitVal: " + InitVal.getFirstToken().toString());
                System.out.println("FuncDef: " + FuncDef.getFirstToken().toString());
                System.out.println("FuncType: " + FuncType.getFirstToken().toString());
                System.out.println("MainFuncDef: " + MainFuncDef.getFirstToken().toString());
                System.out.println("FuncFParams: " + FuncFParams.getFirstToken().toString());
                System.out.println("FuncFParam: " + FuncFParam.getFirstToken().toString());
                System.out.println("Block: " + Block.getFirstToken().toString());
                System.out.println("BlockItem: " + BlockItem.getFirstToken().toString());
                System.out.println("Stmt: " + Stmt.getFirstToken().toString());
                System.out.println("ForStmt: " + ForStmt.getFirstToken().toString());
                System.out.println("Exp: " + Exp.getFirstToken().toString());
                System.out.println("Cond: " + Cond.getFirstToken().toString());
                System.out.println("LVal: " + LVal.getFirstToken().toString());
                System.out.println("PrimaryExp: " + PrimaryExp.getFirstToken().toString());
                System.out.println("Number: " + Number.getFirstToken().toString());
                System.out.println("UnaryExp: " + UnaryExp.getFirstToken().toString());
                System.out.println("UnaryOp: " + UnaryOp.getFirstToken().toString());
                System.out.println("FuncRParams: " + FuncRParams.getFirstToken().toString());
                System.out.println("MulExp: " + MulExp.getFirstToken().toString());
                System.out.println("AddExp: " + AddExp.getFirstToken().toString());
                System.out.println("RelExp: " + RelExp.getFirstToken().toString());
                System.out.println("EqExp: " + EqExp.getFirstToken().toString());
                System.out.println("LAndExp: " + LAndExp.getFirstToken().toString());
                System.out.println("LOrExp: " + LOrExp.getFirstToken().toString());
                System.out.println("ConstExp: " + ConstExp.getFirstToken().toString());
            }
            */
            // 三个都有INTTK，预读两个token
            // { Decl }
            while (pos < tokens.size() &&
                Decl.getFirstToken().contains(TokenTypeat(tokens, pos)) &&
                (
                    (is(tokens,pos, Token.TokenType.INTTK) &&
                        is(tokens,pos+1, Token.TokenType.IDENFR) &&
                        !is(tokens,pos+2, Token.TokenType.LPARENT)
                    )

                    || !is(tokens,pos, Token.TokenType.INTTK)
                )
            ) {
                nodepos r = Decl.parse(tokens, pos,result);
                node.addChild(r.node);
                pos = r.pos;
            }
            // { FuncDef }
            while (pos < tokens.size() &&
                FuncDef.getFirstToken().contains(TokenTypeat(tokens, pos)) &&
                (
                    (is(tokens,pos, Token.TokenType.INTTK) &&
                        is(tokens,pos+1, Token.TokenType.IDENFR) &&
                        is(tokens,pos+2, Token.TokenType.LPARENT)

                    )

                        || TokenTypeat(tokens, pos)!=Token.TokenType.INTTK
                )

            ) {
                nodepos r = FuncDef.parse(tokens, pos,result);
                node.addChild(r.node);
                pos = r.pos;
            }// MainFuncDef
            nodepos main = MainFuncDef.parse(tokens, pos,result);
            node.addChild(main.node);
            pos = main.pos;
            return new nodepos(node, pos);
        }
    }

    // Decl -> ConstDecl | VarDecl
    public class Decl {
        private static ArrayList<Token.TokenType> FirstToken = new ArrayList<>();

        public static List<Token.TokenType> getFirstToken() {
            return FirstToken;
        }
        static {
            getFirstToken().addAll(ConstDecl.getFirstToken());
            getFirstToken().addAll(VarDecl.getFirstToken());
        }

        public static nodepos parse(ArrayList<Token> tokens, int pos,UnitResult result) {
            if (is(tokens, pos, Token.TokenType.CONSTTK)) {
                return ConstDecl.parse(tokens, pos,result);
            } else {
                return VarDecl.parse(tokens, pos,result);
            }
        }
    }

    // ConstDecl -> 'const' BType ConstDef {',' ConstDef} ';'
    public class ConstDecl {
        private static ArrayList<Token.TokenType> FirstToken = new ArrayList<>();

        public static List<Token.TokenType> getFirstToken() {
            return FirstToken;
        }
        static {
            getFirstToken().add(Token.TokenType.CONSTTK);
        }

        public static nodepos parse(ArrayList<Token> tokens, int pos,UnitResult result) {
            int line = at(tokens, pos) != null ? at(tokens, pos).getLineNumber() : 0;
            Unit node = makeUnit(line, Unit.UnitType.ConstDecl);
            // 'const'
            pos = expectToken(result,node, tokens, pos, Token.TokenType.CONSTTK);
            // BType
            nodepos bt = BType.parse(tokens, pos,result);
            node.addChild(bt.node);
            pos = bt.pos;
            while (true) {
                // ConstDef: ident ['[' ConstExp ']'] '=' ConstExp
                nodepos cd = ConstDef.parse(tokens, pos,result);
                node.addChild(cd.node);
                pos = cd.pos;
                if (is(tokens, pos, Token.TokenType.COMMA)) {
                    pos = expectToken(result,node, tokens, pos, Token.TokenType.COMMA);
                    continue;
                }
                break;
            }
            pos = expectToken(result,node, tokens, pos, Token.TokenType.SEMICN);
            return new nodepos(node, pos);
        }
    }

    // ConstDef → Ident [ '[' ConstExp ']' ] '=' ConstInitVal
    public class ConstDef {
        private static ArrayList<Token.TokenType> FirstToken = new ArrayList<>();

        public static List<Token.TokenType> getFirstToken() {
            return FirstToken;
        }
        static {
            getFirstToken().add(Token.TokenType.CONSTTK);
        }

        public static nodepos parse(ArrayList<Token> tokens, int pos,UnitResult result) {
            int line = at(tokens, pos) != null ? at(tokens, pos).getLineNumber() : 0;
            Unit node = makeUnit(line, Unit.UnitType.ConstDef);
            // ident
            pos = expectToken(result,node, tokens, pos, Token.TokenType.IDENFR);
            // {'[' ConstExp ']'}
            while (is(tokens, pos, Token.TokenType.LBRACK)) {
                // '['
                pos = expectToken(result,node, tokens, pos, Token.TokenType.LBRACK);
                // ConstExp
                nodepos ce = ConstExp.parse(tokens, pos,result);
                node.addChild(ce.node);
                pos = ce.pos;
                // ']'
                pos = expectToken(result,node, tokens, pos, Token.TokenType.RBRACK);
            }
            // '='
            pos = expectToken(result,node, tokens, pos, Token.TokenType.ASSIGN);
            // ConstInitVal
            nodepos civ = ConstInitVal.parse(tokens, pos,result);
            node.addChild(civ.node);
            pos = civ.pos;
            return new nodepos(node, pos);

        }
    }
    // ConstInitVal → ConstExp | '{' [ ConstExp { ',' ConstExp } ] '}'
    public class ConstInitVal {
        private static ArrayList<Token.TokenType> FirstToken = new ArrayList<>();

        public static List<Token.TokenType> getFirstToken() {
            return FirstToken;
        }
        static {
            getFirstToken().addAll(ConstExp.getFirstToken());
            getFirstToken().add(Token.TokenType.LBRACE);
        }

        public static nodepos parse(ArrayList<Token> tokens, int pos,UnitResult result) {
            int line = at(tokens, pos) != null ? at(tokens, pos).getLineNumber() : 0;
            Unit node = makeUnit(line, Unit.UnitType.ConstInitVal);
            if (is(tokens, pos, Token.TokenType.LBRACE)) {
                // '{' [ConstExp {',' ConstExp}] '}'
                // '{'
                pos = expectToken(result,node, tokens, pos, Token.TokenType.LBRACE);
                // [ConstExp {',' ConstExp}]
                if (ConstExp.getFirstToken().contains(TokenTypeat(tokens, pos))) {
                    // ConstExp
                    nodepos ce = ConstExp.parse(tokens, pos,result);
                    node.addChild(ce.node);
                    pos = ce.pos;
                    while (is(tokens, pos, Token.TokenType.COMMA)) {
                        // ','
                        pos = expectToken(result,node, tokens, pos, Token.TokenType.COMMA);
                        // ConstExp
                        ce = ConstExp.parse(tokens, pos,result);
                        node.addChild(ce.node);
                        pos = ce.pos;
                    }
                }
                // '}'
                pos = expectToken(result,node, tokens, pos, Token.TokenType.RBRACE);
                return new nodepos(node, pos);
            } else {
                // ConstExp
                nodepos ce = ConstExp.parse(tokens, pos,result);
                node.addChild(ce.node);
                pos = ce.pos;
                return new nodepos(node, pos);

            }

        }
    }

    // BType -> 'int'
    public class BType {
        private static ArrayList<Token.TokenType> FirstToken = new ArrayList<>();

        public static List<Token.TokenType> getFirstToken() {
            return FirstToken;
        }
        static {
            getFirstToken().add(Token.TokenType.INTTK);
        }

        public static nodepos parse(ArrayList<Token> tokens, int pos,UnitResult result) {
            int line = at(tokens, pos) != null ? at(tokens, pos).getLineNumber() : 0;
            if (!is(tokens, pos, Token.TokenType.INTTK)) {
                //result.addErrorMessage(line,"BType error");
            }
            Token t = at(tokens, pos);
            return new nodepos(t, pos+1);
        }

    }

    // VarDecl -> [ 'static' ] BType VarDef { ',' VarDef } ';'
    public class VarDecl {
        private static ArrayList<Token.TokenType> FirstToken = new ArrayList<>();

        public static List<Token.TokenType> getFirstToken() {
            return FirstToken;
        }
        static {
            getFirstToken().add(Token.TokenType.INTTK);
            getFirstToken().add(Token.TokenType.STATICTK);
        }

        public static nodepos parse(ArrayList<Token> tokens, int pos,UnitResult result) {
            int line = at(tokens, pos) != null ? at(tokens, pos).getLineNumber() : 0;
            Unit node = makeUnit(line, Unit.UnitType.VarDecl);
            // [ 'static' ]
            if (is(tokens, pos, Token.TokenType.STATICTK)) {
                pos = expectToken(result,node, tokens, pos, Token.TokenType.STATICTK);
            }
            // BType
            nodepos bt = BType.parse(tokens, pos,result);
            node.addChild(bt.node);
            pos = bt.pos;
            while (true) {
                // VarDef
                nodepos vd = VarDef.parse(tokens, pos,result);
                node.addChild(vd.node);
                pos = vd.pos;
                if (is(tokens, pos, Token.TokenType.COMMA)) {
                    pos = expectToken(result,node, tokens, pos, Token.TokenType.COMMA);
                    continue;
                }
                break;
            }
            // ';'
            pos = expectToken(result,node, tokens, pos, Token.TokenType.SEMICN);
            return new nodepos(node, pos);

        }
    }

    // VarDef -> Ident [ '[' ConstExp ']' ] | Ident [ '[' ConstExp ']' ] '=' InitVal
    public class VarDef {
        private static ArrayList<Token.TokenType> FirstToken = new ArrayList<>();

        public static List<Token.TokenType> getFirstToken() {
            return FirstToken;
        }
        static {
            getFirstToken().add(Token.TokenType.IDENFR);
        }

        public static nodepos parse(ArrayList<Token> tokens, int pos,UnitResult result) {
            int line = at(tokens, pos) != null ? at(tokens, pos).getLineNumber() : 0;
            Unit node = makeUnit(line, Unit.UnitType.VarDef);
            // ident
            pos = expectToken(result,node, tokens, pos, Token.TokenType.IDENFR);
            // {'[' ConstExp ']'}
            while (is(tokens, pos, Token.TokenType.LBRACK)) {
                // '['
                pos = expectToken(result,node, tokens, pos, Token.TokenType.LBRACK);
                // ConstExp
                nodepos ce = ConstExp.parse(tokens, pos,result);
                node.addChild(ce.node);
                pos = ce.pos;
                // ']'
                pos = expectToken(result,node, tokens, pos, Token.TokenType.RBRACK);
            }
            // ['=' InitVal]
            if (is(tokens, pos, Token.TokenType.ASSIGN)) {
                // '='
                pos = expectToken(result,node, tokens, pos, Token.TokenType.ASSIGN);
                // InitVal
                nodepos iv = InitVal.parse(tokens, pos,result);
                node.addChild(iv.node);
                pos = iv.pos;
            }
            return new nodepos(node, pos);
        }
    }

    //InitVal -> Exp | '{' [Exp {',' Exp}] '}'
    public class InitVal {
        private static ArrayList<Token.TokenType> FirstToken = new ArrayList<>();

        public static List<Token.TokenType> getFirstToken() {
            return FirstToken;
        }
        static {
            getFirstToken().addAll(Exp.getFirstToken());
            getFirstToken().add(Token.TokenType.LBRACE);
        }

        public static nodepos parse(ArrayList<Token> tokens, int pos,UnitResult result) {
            int line = at(tokens, pos) != null ? at(tokens, pos).getLineNumber() : 0;
            Unit node = makeUnit(line, Unit.UnitType.InitVal);
            if (is(tokens, pos, Token.TokenType.LBRACE)) {
                // '{' [Exp {',' Exp}] '}'
                // '{'
                pos = expectToken(result,node, tokens, pos, Token.TokenType.LBRACE);
                // [Exp {',' Exp}]
                if (Exp.getFirstToken().contains(TokenTypeat(tokens, pos))) {
                    // Exp
                    nodepos e = Exp.parse(tokens, pos,result);
                    node.addChild(e.node);
                    pos = e.pos;
                    while (is(tokens, pos, Token.TokenType.COMMA)) {
                        // ','
                        pos = expectToken(result,node, tokens, pos, Token.TokenType.COMMA);
                        // Exp
                        e = Exp.parse(tokens, pos,result);
                        node.addChild(e.node);
                        pos = e.pos;
                    }
                }
                // '}'
                pos = expectToken(result,node, tokens, pos, Token.TokenType.RBRACE);
                return new nodepos(node, pos);
            } else {
                // Exp
                nodepos e = Exp.parse(tokens, pos,result);
                node.addChild(e.node);
                pos = e.pos;
                return new nodepos(node, pos);

            }

        }

    }

    // FuncType -> 'void' | 'int'
    public class FuncType {
        private static ArrayList<Token.TokenType> FirstToken = new ArrayList<>();

        public static List<Token.TokenType> getFirstToken() {
            return FirstToken;
        }
        static {
            getFirstToken().add(Token.TokenType.VOIDTK);
            getFirstToken().add(Token.TokenType.INTTK);
        }

        public static nodepos parse(ArrayList<Token> tokens, int pos,UnitResult result) {
            int line = at(tokens, pos) != null ? at(tokens, pos).getLineNumber() : 0;
            Unit node = makeUnit(line, Unit.UnitType.FuncType);
            // 'void' | 'int'
            if (is(tokens, pos, Token.TokenType.VOIDTK)) {
                // 'void'
                pos = expectToken(result,node, tokens, pos, Token.TokenType.VOIDTK);
            } else {
                // 'int'
                pos = expectToken(result,node, tokens, pos, Token.TokenType.INTTK);
            }
            return new nodepos(node, pos);
        }
    }

    // FuncDef -> FuncType Ident '(' [FuncFParams] ')' Block
    public class FuncDef {
        private static ArrayList<Token.TokenType> FirstToken = new ArrayList<>();

        public static List<Token.TokenType> getFirstToken() {
            return FirstToken;
        }
        static {
            getFirstToken().addAll(FuncType.getFirstToken());
        }

        public static nodepos parse(ArrayList<Token> tokens, int pos,UnitResult result) {
            int line = at(tokens, pos) != null ? at(tokens, pos).getLineNumber() : 0;
            Unit node = makeUnit(line, Unit.UnitType.FuncDef);
            // FuncType
            nodepos ft = FuncType.parse(tokens, pos,result);
            node.addChild(ft.node);
            pos = ft.pos;
            // Ident
            pos = expectToken(result,node, tokens, pos, Token.TokenType.IDENFR);
            // '('
            pos = expectToken(result,node, tokens, pos, Token.TokenType.LPARENT);
            // [FuncFParams]
            if (FuncFParams.getFirstToken().contains(at(tokens, pos) != null ? at(tokens, pos).getType() : null)) {
                nodepos fp = FuncFParams.parse(tokens, pos,result);
                node.addChild(fp.node);
                pos = fp.pos;
            }
            // ')'
            pos = expectToken(result,node, tokens, pos, Token.TokenType.RPARENT);
            // Block
            nodepos blk = Block.parse(tokens, pos,result);
            node.addChild(blk.node);
            pos = blk.pos;
            return new nodepos(node, pos);
        }
    }

    // MainFuncDef -> 'int' 'main' '(' ')' Block
    public class MainFuncDef {
        private static ArrayList<Token.TokenType> FirstToken = new ArrayList<>();

        public static List<Token.TokenType> getFirstToken() {
            return FirstToken;
        }
        static {
            getFirstToken().add(Token.TokenType.INTTK);
        }

        public static nodepos parse(ArrayList<Token> tokens, int pos,UnitResult result) {
            int line = at(tokens, pos) != null ? at(tokens, pos).getLineNumber() : 0;
            Unit node = makeUnit(line, Unit.UnitType.MainFuncDef);
            // 'int'
            pos = expectToken(result,node, tokens, pos, Token.TokenType.INTTK);
            // 'main'
            pos = expectToken(result,node, tokens, pos, Token.TokenType.MAINTK);
            // '('
            pos = expectToken(result,node, tokens, pos, Token.TokenType.LPARENT);
            // ')'
            pos = expectToken(result,node, tokens, pos, Token.TokenType.RPARENT);
            // Block
            nodepos blk = Block.parse(tokens, pos,result);
            node.addChild(blk.node);
            pos = blk.pos;
            return new nodepos(node, pos);
        }
    }

    // FuncFParams -> FuncFParam {',' FuncFParam}
    public class FuncFParams {
        private static ArrayList<Token.TokenType> FirstToken = new ArrayList<>();

        public static List<Token.TokenType> getFirstToken() {
            return FirstToken;
        }
        static {
            getFirstToken().addAll(FuncFParam.getFirstToken());
        }

        public static nodepos parse(ArrayList<Token> tokens, int pos,UnitResult result) {
            int line = at(tokens, pos) != null ? at(tokens, pos).getLineNumber() : 0;
            Unit node = makeUnit(line, Unit.UnitType.FuncFParams);
            // FuncFParam
            nodepos fp = FuncFParam.parse(tokens, pos,result);
            node.addChild(fp.node);
            pos = fp.pos;
            // {',' FuncFParam}
            while (is(tokens, pos, Token.TokenType.COMMA)) {
                // ','
                pos = expectToken(result,node, tokens, pos, Token.TokenType.COMMA);
                // FuncFParam
                fp = FuncFParam.parse(tokens, pos,result);
                node.addChild(fp.node);
                pos = fp.pos;
            }
            return new nodepos(node, pos);
        }
    }

    // FuncFParam → BType Ident ['[' ']']
    public class FuncFParam {
        private static ArrayList<Token.TokenType> FirstToken = new ArrayList<>();

        public static List<Token.TokenType> getFirstToken() {
            return FirstToken;
        }
        static {
            getFirstToken().addAll(BType.getFirstToken());
        }

        public static nodepos parse(ArrayList<Token> tokens, int pos,UnitResult result) {
            int line = at(tokens, pos) != null ? at(tokens, pos).getLineNumber() : 0;
            Unit node = makeUnit(line, Unit.UnitType.FuncFParam);
            // BType
            nodepos bt = BType.parse(tokens, pos,result);
            node.addChild(bt.node);
            pos = bt.pos;
            // Ident
            pos = expectToken(result,node, tokens, pos, Token.TokenType.IDENFR);
            // ['[' ']']
            if (is(tokens, pos, Token.TokenType.LBRACK)) {
                // '['
                pos = expectToken(result,node, tokens, pos, Token.TokenType.LBRACK);
                // ']'
                pos = expectToken(result,node, tokens, pos, Token.TokenType.RBRACK);
            }
            return new nodepos(node, pos);
        }
    }

    // Block -> '{' {BlockItem} '}'
    public class Block {
        private static ArrayList<Token.TokenType> FirstToken = new ArrayList<>();

        public static List<Token.TokenType> getFirstToken() {
            return FirstToken;
        }
        static {
            getFirstToken().add(Token.TokenType.LBRACE);
        }

        public static nodepos parse(ArrayList<Token> tokens, int pos,UnitResult result) {
            int line = at(tokens, pos) != null ? at(tokens, pos).getLineNumber() : 0;
            Unit node = makeUnit(line, Unit.UnitType.Block);
            // '{'
            pos = expectToken(result,node, tokens, pos, Token.TokenType.LBRACE);
            // { BlockItem }
            while (pos < tokens.size() && BlockItem.getFirstToken().contains(TokenTypeat(tokens, pos))) {
                nodepos bi = BlockItem.parse(tokens, pos,result);
                node.addChild(bi.node);
                pos = bi.pos;
            }
            // '}'
            pos = expectToken(result,node, tokens, pos, Token.TokenType.RBRACE);
            return new nodepos(node, pos);
        }
    }

    // BlockItem -> Decl | Stmt
    public class BlockItem {
        private static ArrayList<Token.TokenType> FirstToken = new ArrayList<>();

        public static List<Token.TokenType> getFirstToken() {
            return FirstToken;
        }
        static {
            getFirstToken().addAll(Decl.getFirstToken());
            getFirstToken().addAll(Stmt.getFirstToken());
        }

        public static nodepos parse(ArrayList<Token> tokens, int pos,UnitResult result) {
            int line = at(tokens, pos) != null ? at(tokens, pos).getLineNumber() : 0;
            if (Decl.getFirstToken().contains(TokenTypeat(tokens, pos))) {
                // Decl
                return Decl.parse(tokens, pos,result);
            } else if(Stmt.getFirstToken().contains(TokenTypeat(tokens, pos))){
                // Stmt
                return Stmt.parse(tokens, pos,result);
            }
            else {
                //result.addErrorMessage(line,"BlockItem error");
                return new nodepos(makeUnit(line, Unit.UnitType.BlockItem), pos + 1);
            }
        }
    }

    // Stmt -> LVal '=' Exp ';'
    //       | [Exp] ';'
    //       | Block
    //       | 'if' '(' Cond ')' Stmt ['else' Stmt]
    //       | 'for' '(' [ForStmt] ';' [Cond] ';' [ForStmt] ')' Stmt
    //       | 'break' ';'
    //       | 'continue' ';'
    //       | 'return' [Exp] ';'
    //       | 'printf''('StringConst {','Exp}')'';'
    public class Stmt {
        private static ArrayList<Token.TokenType> FirstToken = new ArrayList<>();

        public static List<Token.TokenType> getFirstToken() {
            return FirstToken;
        }
        static {
            getFirstToken().addAll(LVal.getFirstToken());
            getFirstToken().addAll(Exp.getFirstToken());
            getFirstToken().add(Token.TokenType.SEMICN);
            getFirstToken().addAll(Block.getFirstToken());
            getFirstToken().add(Token.TokenType.IFTK);
            getFirstToken().add(Token.TokenType.FORTK);
            getFirstToken().add(Token.TokenType.BREAKTK);
            getFirstToken().add(Token.TokenType.CONTINUETK);
            getFirstToken().add(Token.TokenType.RETURNTK);
            getFirstToken().add(Token.TokenType.PRINTFTK);
        }

        public static nodepos parse(ArrayList<Token> tokens, int pos,UnitResult result) {
            int line = at(tokens, pos) != null ? at(tokens, pos).getLineNumber() : 0;
            Unit node = makeUnit(line, Unit.UnitType.Stmt);
            // LVal '=' Exp ';' | [Exp] ';'
            if (LVal.getFirstToken().contains(TokenTypeat(tokens, pos)) || Exp.getFirstToken().contains(TokenTypeat(tokens, pos))) {
                // 预读LVal，判断是否为赋值语句
                int endpos = LVal.parse_back(tokens, pos);
                // 判断下一个token是否为'='
                if (endpos!=-1 && is(tokens, endpos, Token.TokenType.ASSIGN)) {
                    // LVal '=' Exp ';'
                    // LVal
                    nodepos lv = LVal.parse(tokens, pos,result);
                    node.addChild(lv.node);
                    pos = lv.pos;
                    // '='
                    pos = expectToken(result,node, tokens, pos, Token.TokenType.ASSIGN);
                    // Exp
                    nodepos e = Exp.parse(tokens, pos,result);
                    node.addChild(e.node);
                    pos = e.pos;
                    // ';'
                    pos = expectToken(result,node, tokens, pos, Token.TokenType.SEMICN);
                    return new nodepos(node, pos);
                } else {
                    // [Exp] ';'
                    if (Exp.getFirstToken().contains(TokenTypeat(tokens, pos))) {
                        // Exp
                        nodepos e = Exp.parse(tokens, pos,result);
                        node.addChild(e.node);
                        pos = e.pos;
                    }
                    // ';'
                    pos = expectToken(result,node, tokens, pos, Token.TokenType.SEMICN);
                    return new nodepos(node, pos);
                }


            }
            // ';'
            else if (is(tokens, pos, Token.TokenType.SEMICN)) {
                pos = expectToken(result,node, tokens, pos, Token.TokenType.SEMICN);
                return new nodepos(node, pos);
            }
            // Block
            else if (is(tokens, pos, Token.TokenType.LBRACE)) {
                nodepos blk = Block.parse(tokens, pos,result);
                node.addChild(blk.node);
                pos = blk.pos;
                return new nodepos(node, pos);
            }
            // 'if' '(' Cond ')' Stmt ['else' Stmt]
            else if (is(tokens, pos, Token.TokenType.IFTK)) {
                // 'if'
                pos = expectToken(result,node, tokens, pos, Token.TokenType.IFTK);
                // '('
                pos = expectToken(result,node, tokens, pos, Token.TokenType.LPARENT);
                // Cond
                nodepos c = Cond.parse(tokens, pos,result);
                node.addChild(c.node);
                pos = c.pos;
                // ')'
                pos = expectToken(result,node, tokens, pos, Token.TokenType.RPARENT);
                // Stmt
                nodepos s = Stmt.parse(tokens, pos,result);
                node.addChild(s.node);
                pos = s.pos;
                // ['else' Stmt]
                if (is(tokens, pos, Token.TokenType.ELSETK)) {
                    // 'else'
                    pos = expectToken(result,node, tokens, pos, Token.TokenType.ELSETK);
                    // Stmt
                    s = Stmt.parse(tokens, pos,result);
                    node.addChild(s.node);
                    pos = s.pos;
                }
                return new nodepos(node, pos);
            }
            // 'for' '(' [ForStmt] ';' [Cond] ';' [ForStmt] ')' Stmt
            else if (is(tokens, pos, Token.TokenType.FORTK)) {
                // 'for'
                pos = expectToken(result,node, tokens, pos, Token.TokenType.FORTK);
                // '('
                pos = expectToken(result,node, tokens, pos, Token.TokenType.LPARENT);
                // [ForStmt]
                if (ForStmt.getFirstToken().contains(TokenTypeat(tokens, pos))) {
                    nodepos fs = ForStmt.parse(tokens, pos,result);
                    node.addChild(fs.node);
                    pos = fs.pos;
                }
                // ';'
                pos = expectToken(result,node, tokens, pos, Token.TokenType.SEMICN);
                // [Cond]
                if (Cond.getFirstToken().contains(TokenTypeat(tokens, pos))) {
                    nodepos c = Cond.parse(tokens, pos,result);
                    node.addChild(c.node);
                    pos = c.pos;
                }
                // ';'
                pos = expectToken(result,node, tokens, pos, Token.TokenType.SEMICN);
                // [ForStmt]
                if (ForStmt.getFirstToken().contains(TokenTypeat(tokens, pos))) {
                    nodepos fs = ForStmt.parse(tokens, pos,result);
                    node.addChild(fs.node);
                    pos = fs.pos;
                }
                // ')'
                pos = expectToken(result,node, tokens, pos, Token.TokenType.RPARENT);
                // Stmt
                nodepos s = Stmt.parse(tokens, pos,result);
                node.addChild(s.node);
                pos = s.pos;
                return new nodepos(node, pos);
            }
            // 'break' ';'
            else if (is(tokens, pos, Token.TokenType.BREAKTK)) {
                // 'break'
                pos = expectToken(result,node, tokens, pos, Token.TokenType.BREAKTK);
                // ';'
                pos = expectToken(result,node, tokens, pos, Token.TokenType.SEMICN);
                return new nodepos(node, pos);
            }
            // 'continue' ';'
            else if (is(tokens, pos, Token.TokenType.CONTINUETK)) {
                // 'continue'
                pos = expectToken(result,node, tokens, pos, Token.TokenType.CONTINUETK);
                // ';'
                pos = expectToken(result,node, tokens, pos, Token.TokenType.SEMICN);
                return new nodepos(node, pos);
            }
            // 'return' [Exp] ';'
            else if (is(tokens, pos, Token.TokenType.RETURNTK)) {
                // 'return'
                pos = expectToken(result,node, tokens, pos, Token.TokenType.RETURNTK);
                // [Exp]
                if (Exp.getFirstToken().contains(TokenTypeat(tokens, pos))) {
                    nodepos e = Exp.parse(tokens, pos,result);
                    node.addChild(e.node);
                    pos = e.pos;
                }
                // ';'
                pos = expectToken(result,node, tokens, pos, Token.TokenType.SEMICN);
                return new nodepos(node, pos);

            }
            // 'printf''('StringConst {','Exp}')'';'
            else if (is(tokens, pos, Token.TokenType.PRINTFTK)) {
                // 'printf'
                pos = expectToken(result,node, tokens, pos, Token.TokenType.PRINTFTK);
                // '('
                pos = expectToken(result,node, tokens, pos, Token.TokenType.LPARENT);
                // StringConst
                pos = expectToken(result,node, tokens, pos, Token.TokenType.STRCON);
                // {',' Exp}
                if (is(tokens, pos, Token.TokenType.COMMA)) {
                    // ','
                    pos = expectToken(result,node, tokens, pos, Token.TokenType.COMMA);
                    // Exp
                    nodepos e = Exp.parse(tokens, pos,result);
                    node.addChild(e.node);
                    pos = e.pos;
                    while (is(tokens, pos, Token.TokenType.COMMA)) {
                        // ','
                        pos = expectToken(result,node, tokens, pos, Token.TokenType.COMMA);
                        // Exp
                        e = Exp.parse(tokens, pos,result);
                        node.addChild(e.node);
                        pos = e.pos;
                    }
                }
                // ')'
                pos = expectToken(result,node, tokens, pos, Token.TokenType.RPARENT);
                // ';'
                pos = expectToken(result,node, tokens, pos, Token.TokenType.SEMICN);
                return new nodepos(node, pos);
            }
            else {
                //result.addErrorMessage(line,"Stmt error");
                return new nodepos(node, pos);
            }
        }
    }

    // ForStmt -> LVal '=' Exp { ',' LVal '=' Exp }
    public class ForStmt {
        private static ArrayList<Token.TokenType> FirstToken = new ArrayList<>();

        public static List<Token.TokenType> getFirstToken() {
            return FirstToken;
        }
        static {
            getFirstToken().addAll(LVal.getFirstToken());
        }
        public static nodepos parse(ArrayList<Token> tokens, int pos,UnitResult result) {
            int line = at(tokens, pos) != null ? at(tokens, pos).getLineNumber() : 0;
            Unit node = makeUnit(line, Unit.UnitType.ForStmt);
            while (true) {
                // LVal
                nodepos lv = LVal.parse(tokens, pos,result);
                node.addChild(lv.node);
                pos = lv.pos;
                // '='
                pos = expectToken(result,node, tokens, pos, Token.TokenType.ASSIGN);
                // Exp
                nodepos e = Exp.parse(tokens, pos,result);
                node.addChild(e.node);
                pos = e.pos;
                if (is(tokens, pos, Token.TokenType.COMMA)) {
                    // ','
                    pos = expectToken(result,node, tokens, pos, Token.TokenType.COMMA);
                    continue;
                }
                break;
            }
            return new nodepos(node, pos);
        }
    }

    // Exp -> AddExp
    public class Exp {
        private static ArrayList<Token.TokenType> FirstToken = new ArrayList<>();

        public static List<Token.TokenType> getFirstToken() {
            return FirstToken;
        }
        static {
            getFirstToken().addAll(AddExp.getFirstToken());
        }

        public static nodepos parse(ArrayList<Token> tokens, int pos,UnitResult result) {
            int line = at(tokens, pos) != null ? at(tokens, pos).getLineNumber() : 0;
            Unit node = makeUnit(line, Unit.UnitType.Exp);
            // AddExp
            nodepos ae = AddExp.parse(tokens, pos,result);
            node.addChild(ae.node);
            pos = ae.pos;
            return new nodepos(node, pos);

        }
    }

    // Cond -> LOrExp
    public class Cond {
        private static ArrayList<Token.TokenType> FirstToken = new ArrayList<>();

        public static List<Token.TokenType> getFirstToken() {
            return FirstToken;
        }
        static {
            getFirstToken().addAll(LOrExp.getFirstToken());
        }

        public static nodepos parse(ArrayList<Token> tokens, int pos,UnitResult result) {
            int line = at(tokens, pos) != null ? at(tokens, pos).getLineNumber() : 0;
            Unit node = makeUnit(line, Unit.UnitType.Cond);
            // LOrExp
            nodepos loe = LOrExp.parse(tokens, pos,result);
            node.addChild(loe.node);
            pos = loe.pos;
            return new nodepos(node, pos);
        }
    }

    // LVal -> Ident {'[' Exp ']'}
    public class LVal {
        private static ArrayList<Token.TokenType> FirstToken = new ArrayList<>();

        public static List<Token.TokenType> getFirstToken() {
            return FirstToken;
        }
        static {
            getFirstToken().add(Token.TokenType.IDENFR);
        }

        public static nodepos parse(ArrayList<Token> tokens, int pos,UnitResult result) {
            int line = at(tokens, pos) != null ? at(tokens, pos).getLineNumber() : 0;
            Unit node = makeUnit(line, Unit.UnitType.LVal);
            // Ident
            pos = expectToken(result,node, tokens, pos, Token.TokenType.IDENFR);
            // {'[' Exp ']'}
            while (is(tokens, pos, Token.TokenType.LBRACK)) {
                // '['
                pos = expectToken(result,node, tokens, pos, Token.TokenType.LBRACK);
                // Exp
                nodepos e = Exp.parse(tokens, pos,result);
                node.addChild(e.node);
                pos = e.pos;
                // ']'
                pos = expectToken(result,node, tokens, pos, Token.TokenType.RBRACK);
            }
            return new nodepos(node, pos);
        }
        public static int parse_back(ArrayList<Token> tokens, int pos) {
            // 预读LVal，判断是否为赋值语句,返回结束位置,失败返回-1
            UnitResult temp = new UnitResult();
            int line = at(tokens, pos) != null ? at(tokens, pos).getLineNumber() : 0;
            Unit node = makeUnit(line, Unit.UnitType.LVal);
            // Ident
            pos = expectToken(temp,node, tokens, pos, Token.TokenType.IDENFR);
            // {'[' Exp ']'}
            while (is(tokens, pos, Token.TokenType.LBRACK)) {
                // '['
                pos = expectToken(temp,node, tokens, pos, Token.TokenType.LBRACK);
                // Exp
                nodepos e = Exp.parse(tokens, pos,temp);
                node.addChild(e.node);
                pos = e.pos;
                // ']'
                pos = expectToken(temp,node, tokens, pos, Token.TokenType.RBRACK);
            }
            if (!temp.Success) {
                return -1;
            }
            return pos;
        }

    }

    // PrimaryExp -> '(' Exp ')' | LVal | Number
    public class PrimaryExp {
        private static ArrayList<Token.TokenType> FirstToken = new ArrayList<>();

        public static List<Token.TokenType> getFirstToken() {
            return FirstToken;
        }
        static {
            getFirstToken().add(Token.TokenType.LPARENT);
            getFirstToken().addAll(LVal.getFirstToken());
            getFirstToken().addAll(Number.getFirstToken());
        }

        public static nodepos parse(ArrayList<Token> tokens, int pos,UnitResult result) {
            int line = at(tokens, pos) != null ? at(tokens, pos).getLineNumber() : 0;
            Unit node = makeUnit(line, Unit.UnitType.PrimaryExp);
            // '(' Exp ')'
            if (is(tokens, pos, Token.TokenType.LPARENT)) {
                // '('
                pos = expectToken(result,node, tokens, pos, Token.TokenType.LPARENT);
                // Exp
                nodepos e = Exp.parse(tokens, pos,result);
                node.addChild(e.node);
                pos = e.pos;
                // ')'
                pos = expectToken(result,node, tokens, pos, Token.TokenType.RPARENT);
                return new nodepos(node, pos);
            }
            // LVal
            else if (LVal.getFirstToken().contains(TokenTypeat(tokens, pos))) {
                nodepos lv = LVal.parse(tokens, pos,result);
                node.addChild(lv.node);
                pos = lv.pos;
                return new nodepos(node, pos);
            }
            // Number
            else if (Number.getFirstToken().contains(TokenTypeat(tokens, pos))) {
                nodepos n = Number.parse(tokens, pos,result);
                node.addChild(n.node);
                pos = n.pos;
                return new nodepos(node, pos);
            } else {
                //result.addErrorMessage(line,"PrimaryExp error");
                return new nodepos(node, pos);
            }
        }
    }

    // Number -> IntConst
    public class Number {
        private static ArrayList<Token.TokenType> FirstToken = new ArrayList<>();

        public static List<Token.TokenType> getFirstToken() {
            return FirstToken;
        }
        static {
            getFirstToken().add(Token.TokenType.INTCON);
        }

        public static nodepos parse(ArrayList<Token> tokens, int pos,UnitResult result) {
            int line = at(tokens, pos) != null ? at(tokens, pos).getLineNumber() : 0;
            Unit node = makeUnit(line, Unit.UnitType.Number);
            // IntConst
            pos = expectToken(result,node, tokens, pos, Token.TokenType.INTCON);
            return new nodepos(node, pos);
        }
    }

    // UnaryExp -> PrimaryExp | Ident '(' [FuncRParams] ')' | UnaryOp UnaryExp
    public class UnaryExp {
        private static ArrayList<Token.TokenType> FirstToken = new ArrayList<>();

        public static List<Token.TokenType> getFirstToken() {
            return FirstToken;
        }
        static {
            getFirstToken().addAll(PrimaryExp.getFirstToken());
            getFirstToken().add(Token.TokenType.IDENFR);
            getFirstToken().addAll(UnaryOp.getFirstToken());
        }

        public static nodepos parse(ArrayList<Token> tokens, int pos,UnitResult result) {
            int line = at(tokens, pos) != null ? at(tokens, pos).getLineNumber() : 0;
            Unit node = makeUnit(line, Unit.UnitType.UnaryExp);
            // PrimaryExp
            if (PrimaryExp.getFirstToken().contains(TokenTypeat(tokens, pos)) &&
                (
                    !is(tokens, pos, Token.TokenType.IDENFR) ||
                    (
                        is(tokens, pos, Token.TokenType.IDENFR) &&
                        !is(tokens, pos + 1, Token.TokenType.LPARENT)
                    )

                )
            ) {
                nodepos pe = PrimaryExp.parse(tokens, pos,result);
                node.addChild(pe.node);
                pos = pe.pos;
                return new nodepos(node, pos);
            }
            // Ident '(' [FuncRParams] ')'
            else if (is(tokens, pos, Token.TokenType.IDENFR) &&
                is(tokens, pos + 1, Token.TokenType.LPARENT)) {
                // Ident
                pos = expectToken(result,node, tokens, pos, Token.TokenType.IDENFR);
                // '('
                pos = expectToken(result,node, tokens, pos, Token.TokenType.LPARENT);
                // [FuncRParams]
                if (FuncRParams.getFirstToken().contains(TokenTypeat(tokens, pos))) {
                    nodepos frp = FuncRParams.parse(tokens, pos,result);
                    node.addChild(frp.node);
                    pos = frp.pos;
                }
                // ')'
                pos = expectToken(result,node, tokens, pos, Token.TokenType.RPARENT);
                return new nodepos(node, pos);
            }
            // UnaryOp UnaryExp
            else if (UnaryOp.getFirstToken().contains(TokenTypeat(tokens, pos))) {
                nodepos uo = UnaryOp.parse(tokens, pos,result);
                node.addChild(uo.node);
                pos = uo.pos;
                nodepos ue = UnaryExp.parse(tokens, pos,result);
                node.addChild(ue.node);
                pos = ue.pos;
                return new nodepos(node, pos);
            } else {
                //result.addErrorMessage(line,"UnaryExp error");
                return new nodepos(node, pos);
            }
        }
    }

    // UnaryOp -> '+' | '-' | '!'
    public class UnaryOp {
        private static ArrayList<Token.TokenType> FirstToken = new ArrayList<>();

        public static List<Token.TokenType> getFirstToken() {
            return FirstToken;
        }
        static {
            getFirstToken().add(Token.TokenType.PLUS);
            getFirstToken().add(Token.TokenType.MINU);
            getFirstToken().add(Token.TokenType.NOT);
        }

        public static nodepos parse(ArrayList<Token> tokens, int pos,UnitResult result) {
            int line = at(tokens, pos) != null ? at(tokens, pos).getLineNumber() : 0;
            Unit node = makeUnit(line, Unit.UnitType.UnaryOp);
            // '+' | '-' | '!'
            if (is(tokens, pos, Token.TokenType.PLUS)) {
                // '+'
                pos = expectToken(result,node, tokens, pos, Token.TokenType.PLUS);
            } else if (is(tokens, pos, Token.TokenType.MINU)) {
                // '-'
                pos = expectToken(result,node, tokens, pos, Token.TokenType.MINU);
            } else if (is(tokens, pos, Token.TokenType.NOT)) {
                // '!'
                pos = expectToken(result,node, tokens, pos, Token.TokenType.NOT);
            } else {
                //result.addErrorMessage(line,"UnaryOp error");
                return new nodepos(node, pos);
            }
            return new nodepos(node, pos);
        }
    }

    // FuncRParams -> Exp {',' Exp}
    public class FuncRParams {
        private static ArrayList<Token.TokenType> FirstToken = new ArrayList<>();

        public static List<Token.TokenType> getFirstToken() {
            return FirstToken;
        }
        static {
            getFirstToken().addAll(Exp.getFirstToken());
        }

        public static nodepos parse(ArrayList<Token> tokens, int pos,UnitResult result) {
            int line = at(tokens, pos) != null ? at(tokens, pos).getLineNumber() : 0;
            Unit node = makeUnit(line, Unit.UnitType.FuncRParams);
            // Exp
            nodepos e = Exp.parse(tokens, pos,result);
            node.addChild(e.node);
            pos = e.pos;
            // {',' Exp}
            while (is(tokens, pos, Token.TokenType.COMMA)) {
                // ','
                pos = expectToken(result,node, tokens, pos, Token.TokenType.COMMA);
                // Exp
                e = Exp.parse(tokens, pos,result);
                node.addChild(e.node);
                pos = e.pos;
            }
            return new nodepos(node, pos);
        }
    }

    // MulExp -> UnaryExp | MulExp ('*' | '/' | '%') UnaryExp
    public class MulExp {
        private static ArrayList<Token.TokenType> FirstToken = new ArrayList<>();

        public static List<Token.TokenType> getFirstToken() {
            return FirstToken;
        }
        static {
            getFirstToken().addAll(UnaryExp.getFirstToken());
        }

        public static nodepos parse(ArrayList<Token> tokens, int pos,UnitResult result) {
            int line = at(tokens, pos) != null ? at(tokens, pos).getLineNumber() : 0;
            Unit node = makeUnit(line, Unit.UnitType.MulExp);
            Unit noderesult = makeUnit(line, Unit.UnitType.MulExp);
            // UnaryExp
            nodepos ue = UnaryExp.parse(tokens, pos,result);
            node.addChild(ue.node);
            pos = ue.pos;
            // {('*' | '/' | '%') UnaryExp}
            while (is(tokens, pos, Token.TokenType.MULT) ||
                is(tokens, pos, Token.TokenType.DIV) ||
                is(tokens, pos, Token.TokenType.MOD)) {
                // '*' | '/' | '%'
                pos = expectToken(result,node, tokens, pos, at(tokens, pos).getType());
                // UnaryExp
                ue = UnaryExp.parse(tokens, pos,result);
                node.addChild(ue.node);
                pos = ue.pos;
            }
            // 将所有的子节点重新排列成左结合
            if (node.getChildren().size() >=2) {
                Unit tempNode = noderesult;
                for (int i = node.getChildren().size()-1; i > 0 ; i -= 2) {
                    Unit newNode = makeUnit(line, Unit.UnitType.MulExp);
                    tempNode.addChild(newNode);
                    tempNode.addChild(node.getChildren().get(i-1)); // ('*' | '/' | '%')
                    tempNode.addChild(node.getChildren().get(i)); // UnaryExp
                    tempNode = newNode;
                }
                tempNode.addChild(node.getChildren().get(0)); // 最左边的UnaryExp

            } else {
                // 只有一个UnaryExp
                noderesult = node;
            }
            return new nodepos(noderesult, pos);
        }
    }

    // AddExp -> MulExp | AddExp ('+' | '−') MulExp
    public class AddExp {
        private static ArrayList<Token.TokenType> FirstToken = new ArrayList<>();

        public static List<Token.TokenType> getFirstToken() {
            return FirstToken;
        }
        static {
            getFirstToken().addAll(MulExp.getFirstToken());
        }

        public static nodepos parse(ArrayList<Token> tokens, int pos,UnitResult result) {
            int line = at(tokens, pos) != null ? at(tokens, pos).getLineNumber() : 0;
            Unit node = makeUnit(line, Unit.UnitType.AddExp);
            Unit noderesult = makeUnit(line, Unit.UnitType.AddExp);
            // MulExp
            nodepos me = MulExp.parse(tokens, pos,result);
            node.addChild(me.node);
            pos = me.pos;
            // {('+' | '-') MulExp}
            while (is(tokens, pos, Token.TokenType.PLUS) ||
                is(tokens, pos, Token.TokenType.MINU)) {
                // '+' | '-'
                pos = expectToken(result,node, tokens, pos, at(tokens, pos).getType());
                // MulExp
                me = MulExp.parse(tokens, pos,result);
                node.addChild(me.node);
                pos = me.pos;
            }
            // 将所有的子节点重新排列成左结合
            if (node.getChildren().size() >=2) {
                Unit tempNode = noderesult;
                for (int i = node.getChildren().size()-1; i > 0 ; i -= 2) {
                    Unit newNode = makeUnit(line, Unit.UnitType.AddExp);
                    tempNode.addChild(newNode);
                    tempNode.addChild(node.getChildren().get(i-1)); // ('+' | '-')
                    tempNode.addChild(node.getChildren().get(i)); // MulExp
                    tempNode = newNode;
                }
                tempNode.addChild(node.getChildren().get(0)); // 最左边的MulExp
            }
            else {
                // 只有一个MulExp
                noderesult = node;
            }
            return new nodepos(noderesult, pos);
        }
    }

    // RelExp -> AddExp | RelExp ('<' | '>' | '<=' | '>=') AddExp
    public class RelExp {
        private static ArrayList<Token.TokenType> FirstToken = new ArrayList<>();

        public static List<Token.TokenType> getFirstToken() {
            return FirstToken;
        }
        static {
            getFirstToken().addAll(AddExp.getFirstToken());
        }

        public static nodepos parse(ArrayList<Token> tokens, int pos,UnitResult result) {
            int line = at(tokens, pos) != null ? at(tokens, pos).getLineNumber() : 0;
            Unit node = makeUnit(line, Unit.UnitType.RelExp);
            Unit noderesult = makeUnit(line, Unit.UnitType.RelExp);
            // AddExp
            nodepos a = AddExp.parse(tokens, pos,result);
            node.addChild(a.node);
            pos = a.pos;
            // {('<' | '>' | '<=' | '>=') AddExp}
            while (is(tokens, pos, Token.TokenType.LSS) ||
                is(tokens, pos, Token.TokenType.GRE) ||
                is(tokens, pos, Token.TokenType.LEQ) || is(tokens, pos, Token.TokenType.GEQ)) {
                // '<' | '>' | '<=' | '>='
                pos = expectToken(result,node, tokens, pos, at(tokens, pos).getType());
                // AddExp
                a = AddExp.parse(tokens, pos,result);
                node.addChild(a.node);
                pos = a.pos;
            }
            // 将所有的子节点重新排列成左结合
            if (node.getChildren().size() >=2) {
                Unit tempNode = noderesult;
                for (int i = node.getChildren().size()-1; i > 0 ; i -= 2) {
                    Unit newNode = makeUnit(line, Unit.UnitType.RelExp);
                    tempNode.addChild(newNode);
                    tempNode.addChild(node.getChildren().get(i-1)); // ('<' | '>' | '<=' | '>=')
                    tempNode.addChild(node.getChildren().get(i)); // AddExp
                    tempNode = newNode;
                }
                tempNode.addChild(node.getChildren().get(0)); // 最左边的AddExp
            }
            else {
                // 只有一个AddExp
                noderesult = node;
            }
            return new nodepos(noderesult, pos);
        }
    }

    // EqExp -> RelExp | EqExp ('==' | '!=') RelExp
    public class EqExp {
        private static ArrayList<Token.TokenType> FirstToken = new ArrayList<>();

        public static List<Token.TokenType> getFirstToken() {
            return FirstToken;
        }
        static {
            getFirstToken().addAll(RelExp.getFirstToken());
        }

        public static nodepos parse(ArrayList<Token> tokens, int pos,UnitResult result) {
            int line = at(tokens, pos) != null ? at(tokens, pos).getLineNumber() : 0;
            Unit node = makeUnit(line, Unit.UnitType.EqExp);
            Unit noderesult = makeUnit(line, Unit.UnitType.EqExp);
            // RelExp
            nodepos r = RelExp.parse(tokens, pos,result);
            node.addChild(r.node);
            pos = r.pos;
            // {('==' | '!=') RelExp}
            while (is(tokens, pos, Token.TokenType.EQL) ||
                is(tokens, pos, Token.TokenType.NEQ)) {
                // '==' | '!='
                pos = expectToken(result,node, tokens, pos, at(tokens, pos).getType());
                // RelExp
                r = RelExp.parse(tokens, pos,result);
                node.addChild(r.node);
                pos = r.pos;
            }
            // 将所有的子节点重新排列成左结合
            if (node.getChildren().size() >=2) {
                Unit tempNode = noderesult;
                for (int i = node.getChildren().size()-1; i > 0 ; i -= 2) {
                    Unit newNode = makeUnit(line, Unit.UnitType.EqExp);
                    tempNode.addChild(newNode);
                    tempNode.addChild(node.getChildren().get(i-1)); // ('==' | '!=')
                    tempNode.addChild(node.getChildren().get(i)); // RelExp
                    tempNode = newNode;
                }
                tempNode.addChild(node.getChildren().get(0)); // 最左边的RelExp
            }
            else {
                // 只有一个RelExp
                noderesult = node;
            }
            return new nodepos(noderesult, pos);
        }
    }

    // LAndExp -> EqExp | LAndExp '&&' EqExp
    public class LAndExp {
        private static ArrayList<Token.TokenType> FirstToken = new ArrayList<>();

        public static List<Token.TokenType> getFirstToken() {
            return FirstToken;
        }
        static {
            getFirstToken().addAll(EqExp.getFirstToken());
        }

        public static nodepos parse(ArrayList<Token> tokens, int pos,UnitResult result) {
            int line = at(tokens, pos) != null ? at(tokens, pos).getLineNumber() : 0;
            Unit node = makeUnit(line, Unit.UnitType.LAndExp);
            Unit noderesult = makeUnit(line, Unit.UnitType.LAndExp);
            // EqExp
            nodepos e = EqExp.parse(tokens, pos,result);
            node.addChild(e.node);
            pos = e.pos;
            // {'&&' EqExp}
            while (is(tokens, pos, Token.TokenType.AND)) {
                // '&&'
                pos = expectToken(result,node, tokens, pos, Token.TokenType.AND);
                // EqExp
                e = EqExp.parse(tokens, pos,result);
                node.addChild(e.node);
                pos = e.pos;
            }
            // 将所有的子节点重新排列成左结合
            if (node.getChildren().size() >=2) {
                Unit tempNode = noderesult;
                for (int i = node.getChildren().size()-1; i > 0 ; i -= 2) {
                    Unit newNode = makeUnit(line, Unit.UnitType.LAndExp);
                    tempNode.addChild(newNode);
                    tempNode.addChild(node.getChildren().get(i-1)); // '&&'
                    tempNode.addChild(node.getChildren().get(i)); // EqExp
                    tempNode = newNode;
                }
                tempNode.addChild(node.getChildren().get(0)); // 最左边的EqExp
            }
            else {
                // 只有一个EqExp
                noderesult = node;
            }
            return new nodepos(noderesult, pos);
        }
    }

    // LOrExp -> LAndExp | LOrExp '||' LAndExp
    public class LOrExp {
        private static ArrayList<Token.TokenType> FirstToken = new ArrayList<>();

        public static List<Token.TokenType> getFirstToken() {
            return FirstToken;
        }
        static {
            getFirstToken().addAll(LAndExp.getFirstToken());

        }
        public static nodepos parse(ArrayList<Token> tokens, int pos,UnitResult result) {
            int line = at(tokens, pos) != null ? at(tokens, pos).getLineNumber() : 0;
            Unit node = makeUnit(line, Unit.UnitType.LOrExp);
            Unit noderesult = makeUnit(line, Unit.UnitType.LOrExp);
            // LAndExp
            nodepos la = LAndExp.parse(tokens, pos,result);
            node.addChild(la.node);
            pos = la.pos;
            // {'||' LAndExp}
            while (is(tokens, pos, Token.TokenType.OR)) {
                // '||'
                pos = expectToken(result,node, tokens, pos, Token.TokenType.OR);
                // LAndExp
                la = LAndExp.parse(tokens, pos,result);
                node.addChild(la.node);
                pos = la.pos;
            }
            // 将所有的子节点重新排列成左结合
            if (node.getChildren().size() >=2) {
                Unit tempNode = noderesult;
                for (int i = node.getChildren().size()-1; i > 0 ; i -= 2) {
                    Unit newNode = makeUnit(line, Unit.UnitType.LOrExp);
                    tempNode.addChild(newNode);
                    tempNode.addChild(node.getChildren().get(i-1)); // '||'
                    tempNode.addChild(node.getChildren().get(i)); // LAndExp
                    tempNode = newNode;
                }
                tempNode.addChild(node.getChildren().get(0)); // 最左边的LAndExp
            }
            else {
                // 只有一个LAndExp
                noderesult = node;
            }
            return new nodepos(noderesult, pos);
        }
    }

    // ConstExp -> AddExp
    public class ConstExp {
        private static ArrayList<Token.TokenType> FirstToken = new ArrayList<>();

        public static List<Token.TokenType> getFirstToken() {
            return FirstToken;
        }
        static {
            getFirstToken().addAll(AddExp.getFirstToken());
        }

        public static nodepos parse(ArrayList<Token> tokens, int pos,UnitResult result) {
            int line = at(tokens, pos) != null ? at(tokens, pos).getLineNumber() : 0;
            Unit node = makeUnit(line, Unit.UnitType.ConstExp);
            // AddExp
            nodepos a = AddExp.parse(tokens, pos,result);
            node.addChild(a.node);
            pos = a.pos;
            return new nodepos(node, pos);
        }
    }
}
