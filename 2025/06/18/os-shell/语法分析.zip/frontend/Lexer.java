package frontend;
import frontend.nodes.Token;
import frontend.result.TokenResult;

import java.util.*;

public class Lexer {
    // 错误信息
    private static final String errorType_Token = "a";

    // 关键字映射
    private static final Map<String, Token.TokenType> KEYWORDS = new HashMap<>() {{
        put("const", Token.TokenType.CONSTTK);
        put("int", Token.TokenType.INTTK);
        put("static", Token.TokenType.STATICTK);
        put("break", Token.TokenType.BREAKTK);
        put("continue", Token.TokenType.CONTINUETK);
        put("if", Token.TokenType.IFTK);
        put("main", Token.TokenType.MAINTK);
        put("else", Token.TokenType.ELSETK);
        put("for", Token.TokenType.FORTK);
        put("void", Token.TokenType.VOIDTK);
        put("printf", Token.TokenType.PRINTFTK);
        put("return", Token.TokenType.RETURNTK);
    }};

    // 符号映射
    private static final Map<String, Token.TokenType>SYMBOLS = new HashMap<>() {{
        put(";", Token.TokenType.SEMICN);
        put(",", Token.TokenType.COMMA);
        put("!", Token.TokenType.NOT);
        put("&&", Token.TokenType.AND);
        put("||", Token.TokenType.OR);
        put("(", Token.TokenType.LPARENT);
        put(")", Token.TokenType.RPARENT);
        put("[", Token.TokenType.LBRACK);
        put("]", Token.TokenType.RBRACK);
        put("{", Token.TokenType.LBRACE);
        put("}", Token.TokenType.RBRACE);
        put("+", Token.TokenType.PLUS);
        put("-", Token.TokenType.MINU);
        put("*", Token.TokenType.MULT);
        put("/", Token.TokenType.DIV);
        put("%", Token.TokenType.MOD);
        put("<", Token.TokenType.LSS);
        put("<=", Token.TokenType.LEQ);
        put(">", Token.TokenType.GRE);
        put(">=", Token.TokenType.GEQ);
        put("==", Token.TokenType.EQL);
        put("!=", Token.TokenType.NEQ);
        put("=", Token.TokenType.ASSIGN);
    }};

    // 添加单个token
    private static boolean addToken(Integer lineNumber,String tokenStr, ArrayList<Token> tokens) {
        if (SYMBOLS.containsKey(tokenStr)) {// 符号
            tokens.add(new Token(lineNumber, SYMBOLS.get(tokenStr), tokenStr));
        }
        else if (KEYWORDS.containsKey(tokenStr)) {// 关键字
            tokens.add(new Token(lineNumber,KEYWORDS.get(tokenStr), tokenStr));
        }
        else if (tokenStr.matches("\"[^\"]*\"")) {// 标识符
            tokens.add(new Token(lineNumber, Token.TokenType.STRCON, tokenStr) );
        }
        else if (tokenStr.matches("[a-zA-Z_][a-zA-Z0-9_]*")) {// 标识符
            tokens.add(new Token(lineNumber,Token.TokenType.IDENFR, tokenStr));
        }
        else if (tokenStr.matches("\\d+")) {// 整数常量
            tokens.add(new Token(lineNumber,Token.TokenType.INTCON, tokenStr, Integer.parseInt(tokenStr)));
        }
        else {// 非法token
            // 防止语法分析时因为词法错误导致多余的错误
            if (tokenStr.matches("\\|")) {
                tokens.add(new Token(lineNumber,Token.TokenType.OR, tokenStr));
            }
            else if (tokenStr.matches("&")) {
                tokens.add(new Token(lineNumber,Token.TokenType.AND, tokenStr));
            }
            else {
                tokens.add(new Token(lineNumber,Token.TokenType.ERROR, tokenStr));
            }
            return false;
        }
        return true;
    }

    // 处理当前已记录的token并添加到列表
    private static boolean handleToken(Integer lineNumber ,StringBuilder token, ArrayList<Token> tokens) {
        boolean judgeSuccess = true;
        if (!token.isEmpty()) {
            String tokenStr = token.toString();
            if (!addToken(lineNumber,tokenStr, tokens)) {
                judgeSuccess = false;
            }
            token.setLength(0);// 清空当前token
        }
        return judgeSuccess;
    }

    // 词法分析主函数
    public static void analyzeLine(Integer lineNumber,String line,TokenResult result) {
        line = line+" "; // 添加一个空格以确保最后一个token被处理
        ArrayList<Token> tokens = new ArrayList<>();
        StringBuilder token = new StringBuilder();
        boolean Success = true;
        String errorType;

        for (int i = 0; i < line.length(); i++) {
            char c = line.charAt(i);

            // 检查是否是双字符符号
            if (i < line.length() - 1) {
                String twoChar = line.substring(i, i + 2);
                if (SYMBOLS.containsKey(twoChar)) {
                    //处理该字符前的token
                    if (!handleToken(lineNumber,token, tokens)) {
                        Success = false;
                        token.setLength(0);
                        continue;
                    }
                    addToken(lineNumber,twoChar, tokens);
                    i++; // 跳过第二个字符
                    continue;
                }
            }

            // 检查是否是单字符符号
            if (SYMBOLS.containsKey(String.valueOf(c))) {
                if (!handleToken(lineNumber,token, tokens)) {
                    Success = false;
                    token.setLength(0);
                    continue;
                }
                String oneChar = String.valueOf(c);
                addToken(lineNumber,oneChar, tokens);
            } else if (c == '"') {
                // 处理字符串常量
                if (!handleToken(lineNumber,token, tokens)) {
                    Success = false;
                    token.setLength(0);
                    continue;
                }
                int endIndex = line.indexOf('"', i + 1);
                if (endIndex == -1) {
                    Success = false;
                    token.setLength(0);
                    continue;
                }
                String str = line.substring(i, endIndex + 1);
                addToken(lineNumber,str, tokens);
                i = endIndex; // 跳过整个字符串
            } else if (Character.isWhitespace(c)) {
                if (!handleToken(lineNumber,token, tokens)) {
                    Success = false;
                    token.setLength(0);
                    continue;
                }
            } else {
                token.append(c);
            }
        }
        result.tokens.addAll(tokens);
        if (!Success) {
            result.Success = false;
            result.addErrorMessage(lineNumber, Lexer.errorType_Token);
        }
    }

}
