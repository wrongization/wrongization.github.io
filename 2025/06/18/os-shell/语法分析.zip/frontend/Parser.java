package frontend;
import frontend.nodes.Token;
import frontend.nodes.Unit;
import frontend.result.UnitResult;
import frontend.BNF.Gram.*;
import java.util.ArrayList;

public class Parser {

    // 语法分析主函数
    public static void analyze(ArrayList<Token> tokens, UnitResult result) {
        // 语法分析
        nodepos r = CompUnit.parse(tokens, 0,result);
        Unit root = (Unit) r.node;
        result.setroot(root);
    }
}

