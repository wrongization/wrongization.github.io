package frontend.nodes;

import java.io.BufferedWriter;
import java.io.IOException;
import java.util.ArrayList;

// 语法树节点抽象类
public abstract class Node {
    public enum NodeType {
        NON_TERMINAL,
        TERMINAL
    }
    private final Integer lineNumber;
    private Node parent = null;
    private final ArrayList<Node> children;
    private final NodeType nodeType;
    public Node(Integer lineNumber,NodeType type) {
        this.nodeType = type;
        this.lineNumber = lineNumber;
        this.children = new ArrayList<>();
    }
    public void addChild(Node child) {
        this.children.add(child);
        child.parent = this;
    }
    public void removeChild(Node child) {
        this.children.remove(child);
        child.parent = null;
    }
    public Node getParent() {
        return parent;
    }
    public ArrayList<Node> getChildren() {
        return children;
    }
    public NodeType getNodeType() {
        return nodeType;
    }
    public Integer getLineNumber() {
        if (lineNumber == null) {
            return 0;
        }
        return lineNumber;
    }
    public void output(BufferedWriter parseWriter) {
        if(nodeType == NodeType.NON_TERMINAL) {
            for (Node child : children) {
                child.output(parseWriter);
            }
            try {
                parseWriter.write(this.toString());
                parseWriter.newLine();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }

        }
        else {
            try {
                parseWriter.write(this.toString());
                parseWriter.newLine();
            }
            catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
    }
}
