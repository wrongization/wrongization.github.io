package frontend.nodes;

// Token类定义
public class Token extends Node {
    private final TokenType type;
    private final String value;
    private final Integer intValue;
    public enum TokenType {
        CONSTTK,
        INTTK,
        STATICTK,
        RETURNTK,
        BREAKTK,
        CONTINUETK,
        IFTK,
        ELSETK,
        FORTK,
        VOIDTK,
        MAINTK,
        PRINTFTK,
        SEMICN,
        COMMA,
        NOT,
        AND,
        OR,
        LPARENT,
        RPARENT,
        LBRACK,
        RBRACK,
        LBRACE,
        RBRACE,
        PLUS,
        MINU,
        MULT,
        DIV,
        MOD,
        LSS,
        LEQ,
        GRE,
        GEQ,
        EQL,
        NEQ,
        ASSIGN,
        IDENFR,
        INTCON,
        STRCON,
        ERROR
    }

    public Token(Integer lineNumber,TokenType tokentype, String value) {
        super(lineNumber,NodeType.TERMINAL);
        this.type = tokentype;
        this.value = value;
        this.intValue = null;
    }

    public Token(Integer lineNumber,TokenType tokentype, String value, int intValue) {
        super(lineNumber,NodeType.TERMINAL);
        this.type = tokentype;
        this.value = value;
        this.intValue = intValue;
    }

    public TokenType getType() {
        return type;
    }

    public String getValue() {
        return value;
    }

    public Integer getIntValue() {
        return intValue;
    }

    @Override
    public String toString() {
        return type.toString() + " " + value;
    }
}
