package frontend.nodes;

public class Unit extends Node {
    private final UnitType type;
    public enum UnitType {
        CompUnit,
        Decl,
        ConstDecl,
        ConstDef,
        ConstInitVal,
        BType,
        VarDecl,
        VarDef,
        InitVal,
        FuncDef,
        FuncType,
        MainFuncDef,
        FuncFParams,
        FuncFParam,
        Block,
        BlockItem,
        Stmt,
        ForStmt,
        Exp,
        Cond,
        LVal,
        PrimaryExp,
        Number,
        UnaryExp,
        UnaryOp,
        FuncRParams,
        MulExp,
        AddExp,
        RelExp,
        EqExp,
        LAndExp,
        LOrExp,
        ConstExp
    }

    public Unit(Integer lineNumber,UnitType type) {
        super( lineNumber,NodeType.NON_TERMINAL);
        this.type = type;
    }
    public UnitType getType() {
        return type;
    }

    @Override
    public String toString() {
        return "<"+type.toString()+">";
    }
}
