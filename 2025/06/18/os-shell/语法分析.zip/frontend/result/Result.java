package frontend.result;

import java.util.ArrayList;

// 分析结果基类
public class Result {
    public boolean Success;
    public ArrayList<String> errorMessages ;
    public Result() {
        this.Success = true;
        this.errorMessages = new ArrayList<>();
    }
    public void addErrorMessage(Integer linenum ,String errorType) {
        this.errorMessages.add(linenum + " " + errorType);
    }
}