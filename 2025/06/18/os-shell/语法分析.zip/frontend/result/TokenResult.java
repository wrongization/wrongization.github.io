package frontend.result;

import frontend.nodes.Token;

import java.util.ArrayList;
import java.util.List;

// 词法分析结果类
public class TokenResult extends Result {
    public List<Token> tokens;
    public TokenResult() {
        super();
        this.tokens = new ArrayList<>();
    }
}
