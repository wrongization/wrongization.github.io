package frontend.result;
import frontend.nodes.Unit;

// 语法分析结果类
public class UnitResult extends Result {
    public Unit root;
    public UnitResult() {
        super();
    }
    public void setroot(Unit root){
        this.root = root;
    }

}
