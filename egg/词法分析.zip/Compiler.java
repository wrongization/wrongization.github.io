import frontend.Lexer;
import java.io.*;
import java.util.ArrayList;

public class Compiler {
    public static void main(String[] args) throws IOException {
        File inputFile = new File("testfile.txt");
        if (!inputFile.exists()) {
            inputFile.createNewFile();
        }
        File lexerOutput = new File("lexer.txt");
        if (!lexerOutput.exists()) {
            lexerOutput.createNewFile();
        }
        File errorOutput = new File("error.txt");
        if (!errorOutput.exists()) {
            errorOutput.createNewFile();
        }
        ArrayList<Lexer.Token> tokens = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(inputFile));
             BufferedWriter lexerWriter = new BufferedWriter(new FileWriter(lexerOutput));
             BufferedWriter errorWriter = new BufferedWriter(new FileWriter(errorOutput))) {
            String line;
            int lineNumber = 0;
            //处理reader里的注释，包括//和/* */
            boolean inBlockComment = false;
            while ((line = reader.readLine()) != null) {
                lineNumber++;
                StringBuilder newLine = new StringBuilder();
                int i = 0;
                while (i < line.length()) {
                    if (!inBlockComment) {
                        if (i + 1 < line.length() && line.charAt(i) == '/' && line.charAt(i + 1) == '/') {
                            // 单行注释，忽略后续内容
                            break;
                        } else if (i + 1 < line.length() && line.charAt(i) == '/' && line.charAt(i + 1) == '*') {
                            // 进入多行注释
                            inBlockComment = true;
                            i += 2;
                        } else {
                            newLine.append(line.charAt(i));
                            i++;
                        }
                    } else {
                        if (i + 1 < line.length() && line.charAt(i) == '*' && line.charAt(i + 1) == '/') {
                            // 结束多行注释
                            inBlockComment = false;
                            i += 2;
                        } else {
                            i++;
                        }
                    }
                }
                String processedLine = newLine.toString();
                if (processedLine.trim().isEmpty()) {
                    continue;
                }
                // 调用 Lexer 进行词法分析
                Lexer.TokenResult result = Lexer.analyzeLine(processedLine);

                if (!result.Success) {
                    // 有错误时写入错误文件
                    errorWriter.write(lineNumber + " " + result.errorMessage);
                    errorWriter.newLine();
                }
                else {
                    // 没有错误时写入词法分析结果
                    for (Lexer.Token token : result.tokens) {
                        tokens.add(token);
                        lexerWriter.write(token.toString());
                        lexerWriter.newLine();
                    }
                }
            }



        }
        catch (IOException e) {
            e.printStackTrace();
        }


        System.out.println("词法分析完成！");
    }


}