package frontend;
import java.util.*;

public class Lexer {
    // 错误信息
    private static final String errorMessage_Token = "a";

    // 关键字映射
    private static final Map<String, String> KEYWORDS = new HashMap<>() {{
        put("const", "CONSTTK");
        put("int", "INTTK");
        put("static", "STATICTK");
        put("return", "RETURNTK");
        put("break", "BREAKTK");
        put("continue", "CONTINUETK");
        put("if", "IFTK");
        put("else", "ELSETK");
        put("for", "FORTK");
        put("void", "VOIDTK");
        put("main", "MAINTK");
        put("printf", "PRINTFTK");
    }};

    // 符号映射
    private static final Map<String, String> SYMBOLS = new HashMap<>() {{
        put(";", "SEMICN");
        put(",", "COMMA");
        put("!", "NOT");
        put("&&", "AND");
        put("||", "OR");
        put("(", "LPARENT");
        put(")", "RPARENT");
        put("[", "LBRACK");
        put("]", "RBRACK");
        put("{", "LBRACE");
        put("}", "RBRACE");
        put("+", "PLUS");
        put("-", "MINU");
        put("*", "MULT");
        put("/", "DIV");
        put("%", "MOD");
        put("<", "LSS");
        put("<=", "LEQ");
        put(">", "GRE");
        put(">=", "GEQ");
        put("==", "EQL");
        put("!=", "NEQ");
        put("=", "ASSIGN");
    }};

    // Token类定义
    public static class Token {
        private final String type;
        private final String value;
        private final Integer intValue;

        public Token(String type, String value) {
            this.type = type;
            this.value = value;
            this.intValue = null;
        }

        public Token(String type, String value, int intValue) {
            this.type = type;
            this.value = value;
            this.intValue = intValue;
        }

        public String getType() {
            return type;
        }

        public String getValue() {
            return value;
        }

        public Integer getIntValue() {
            return intValue;
        }

        @Override
        public String toString() {
            return type + " " + value;
        }
    }

    // 词法分析结果类
    public static class TokenResult {
        public boolean Success;
        public List<Token> tokens;
        public String errorMessage;

        public TokenResult(boolean hasError, List<Token> tokens, String errorMessage) {
            this.Success = hasError;
            this.tokens = tokens;
            this.errorMessage = errorMessage;
        }
    }

    // 添加单个token
    private static boolean addToken(String tokenStr, List<Token> tokens) {
        if (SYMBOLS.containsKey(tokenStr)) {// 符号
            tokens.add(new Token(SYMBOLS.get(tokenStr), tokenStr));
        }
        else if (KEYWORDS.containsKey(tokenStr)) {// 关键字
            tokens.add(new Token(KEYWORDS.get(tokenStr), tokenStr));
        }
        else if (tokenStr.matches("\"[^\"]*\"")) {// 标识符
            tokens.add(new Token("STRCON", tokenStr));
        }
        else if (tokenStr.matches("[a-zA-Z_][a-zA-Z0-9_]*")) {// 标识符
            tokens.add(new Token("IDENFR", tokenStr));
        }
        else if (tokenStr.matches("\\d+")) {// 整数常量
            tokens.add(new Token("INTCON", tokenStr, Integer.parseInt(tokenStr)));
        }
        else {// 非法token
            return false;
        }
        return true;
    }

    // 处理当前token并添加到列表
    private static boolean handleToken(StringBuilder token, List<Token> tokens) {
        boolean judgeSuccess = true;
        if (!token.isEmpty()) {
            String tokenStr = token.toString();
            if (!addToken(tokenStr, tokens)) {
                judgeSuccess = false;
            }
            token.setLength(0);// 清空token
        }
        return judgeSuccess;
    }

    // 词法分析主函数
    public static TokenResult analyzeLine(String line) {
        line = line+" "; // 添加一个空格以确保最后一个token被处理
        List<Token> tokens = new ArrayList<>();
        StringBuilder token = new StringBuilder();
        boolean Success = true;

        for (int i = 0; i < line.length(); i++) {
            char c = line.charAt(i);

            // 检查是否是双字符符号
            if (i < line.length() - 1) {
                String twoChar = line.substring(i, i + 2);
                if (SYMBOLS.containsKey(twoChar)) {
                    Success = handleToken(token, tokens);//处理该字符前的token
                    if (!Success) break;
                    addToken(twoChar, tokens);
                    i++; // 跳过第二个字符
                    continue;
                }
            }

            // 检查是否是单字符符号
            if (SYMBOLS.containsKey(String.valueOf(c))) {
                Success = handleToken(token, tokens);
                if (!Success) break;
                String oneChar = String.valueOf(c);
                addToken(oneChar, tokens);
            } else if (c == '"') {
                // 处理字符串常量
                Success = handleToken(token, tokens);
                if (!Success) break;
                int endIndex = line.indexOf('"', i + 1);
                if (endIndex == -1) {
                    Success = false;
                    break;
                }
                String str = line.substring(i, endIndex + 1);
                addToken(str, tokens);
                i = endIndex; // 跳过整个字符串
            } else if (Character.isWhitespace(c)) {
                Success= handleToken(token, tokens);
                if (!Success) break;
            } else {
                token.append(c);
            }
        }
        return new TokenResult(Success, tokens, Success ? "" : Lexer.errorMessage_Token);
    }

}
